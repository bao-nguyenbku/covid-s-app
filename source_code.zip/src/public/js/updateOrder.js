/* $(document).ready(function() {
    $('#save-order-btn').click(function() {
        $.ajax({
            type: 'post',
            url: '/waiting/update',
            data: $('#edit-order').serialize(),
            success: function(res) {
                if (res.code == 200) {
                    console.log(res);
                }
                console.log(res);
            }
        });
    });
}); */