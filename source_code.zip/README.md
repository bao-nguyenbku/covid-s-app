# COVID-S PROJECT
Hướng dẫn chạy ứng dụng:
Lưu ý: máy tính cần cài đặt nodejs
Vào folder src/database, import file "covid_support_update_27_11_2021" vào DBMS mySQL
1. Tại folder gốc của dự án (covid-s-project) chạy lệnh "npm start" trong terminal.
    Theo mặc định port chạy ứng dụng là 3060 (có thể đổi port tại file index.js trong covid-s-project nếu bị xung đột)
    Nếu bị lỗi port 3060 đang sử dụng, chạy lệnh "npm stop" để kill toàn bộ port đang chạy và "npm start" lần nữa.
2. Sau khi hiển thị "Database is connected" trong console, vào trình duyệt nhập url: localhost:3060, truy cập ứng dụng thành công