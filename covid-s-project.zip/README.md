# COVID-S PROJECT
Sign in, Sign up for both volunteer and customer: Done\\
Doctor for customer with filter: Done\\
Watch waiting orders of customer after send support request: Need to fix UI\\

